/*
Navicat MySQL Data Transfer

Source Server         : localhost_3306
Source Server Version : 50627
Source Host           : localhost:3306
Source Database       : crawler

Target Server Type    : MYSQL
Target Server Version : 50627
File Encoding         : 65001

Date: 2015-11-17 21:24:49
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for 2014302580377_professor_info
-- ----------------------------
DROP TABLE IF EXISTS `2014302580377_professor_info`;
CREATE TABLE `2014302580377_professor_info` (
  `name` varchar(45) COLLATE utf8_bin NOT NULL,
  `educationBackground` varchar(1000) COLLATE utf8_bin DEFAULT NULL,
  `researchInterests` varchar(1000) COLLATE utf8_bin DEFAULT NULL,
  `email` varchar(45) COLLATE utf8_bin DEFAULT NULL,
  `phone` varchar(45) COLLATE utf8_bin DEFAULT NULL,
  PRIMARY KEY (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;
