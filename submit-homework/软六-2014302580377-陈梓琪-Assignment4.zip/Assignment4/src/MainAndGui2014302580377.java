import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;


public class MainAndGui2014302580377 {
	private static JTextField keyword;
	private static JButton search;
	private static JTextArea result;
	private static JFrame frame = new JFrame();
	private static String input = "";
	private static KeywordsMatcher2014302580377 keywordsmatcher = new KeywordsMatcher2014302580377();
	
	private static ArrayList<ProfessorInfo2014302580377> list = new ArrayList<ProfessorInfo2014302580377>();
	
	public static void MyGui(){
		frame.setVisible(true);
		//frame.setSize(450,450);
		frame.setTitle("Professor Searcher");
		frame.setBounds(100, 100, 420, 413);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		//keyword�����
		keyword = new JTextField(10);
		keyword.setEditable(true);
		keyword.setBounds(20,20,200,30);
		frame.getContentPane().add(keyword);
		
		//����button
		search = new JButton("search");
		search.setVisible(true);
		search.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent e){
				input = keyword.getText();
				list = keywordsmatcher.fetchKeywords(input);
				for(ProfessorInfo2014302580377 pi:list){
					//result.append("search: "+input+'\n');
					result.append(pi.name+'\n'+pi.educationBackground+'\n'
							+pi.researchInterests+'\n'+pi.email+'\n'+pi.phone);
					result.append('\n'+String.valueOf(pi.tf)+'\n');
				}
				
			}
		});
		search.setBounds(240,20,80,30);
		frame.getContentPane().add(search);
		
		//��������
		result = new JTextArea();
		result.setBounds(20,50,360,100);
		result.setRows(5);
		result.setEditable(false);
		frame.getContentPane().add(result);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(20, 60, 360, 300);
		frame.getContentPane().add(scrollPane);
		scrollPane.setViewportView(result);
	}
	
	public static void main(String[] args){
		MyGui();
	}
}
