import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;


public class DataReader2014302580377 {
	private static String url = "jdbc:mysql://127.0.0.1:3306/my_schema";
	private static String password = "123456";
	private static String user = "root";
						
	
	//private ProfessorInfo pi;
	
	public static PreparedStatement getConnection(){
		String sql = "select *from 2014302580377_professor_info";
		//�������ݿ����ݱ�
		try {
			Class.forName("com.mysql.jdbc.Driver");
			Connection conn=DriverManager.getConnection(url,user,password);
			PreparedStatement stmt=conn.prepareStatement(sql);
			return stmt;
		} catch (Exception e) {
			// TODO Auto-generated catch block
			System.out.println("�������ݿ�ʧ��!");
			e.getMessage();
			return null;
		}
		
	}
	//�������ݿ��ֵɶɶɶ��
	public static ArrayList<ProfessorInfo2014302580377> getTextContents(PreparedStatement stmt) throws SQLException{
		String sql = "SELECT name, educationBackground, researchInterests, email, phone FROM 2014302580377_Professor_info";
		ResultSet data = stmt.executeQuery(sql);
		ArrayList<ProfessorInfo2014302580377> list = new ArrayList<ProfessorInfo2014302580377>();	//����һ��ɶ���ţ�
		//ArrayList<String> info = new ArrayList<String>();
		//����ѭ���õ�ֵ
		while(data.next()){
			ProfessorInfo2014302580377 pi = new ProfessorInfo2014302580377();
			pi.name = data.getString("name");
			pi.educationBackground = data.getString("educationBackground");
			pi.researchInterests = data.getString("researchInterests");
			pi.email = data.getString("email");
			pi.phone = data.getString("phone");
			
			list.add(pi);
		}
		return list;
	}
	//�������ݿ�ֵ
	public static ArrayList<ProfessorInfo2014302580377> getList(){
		try {
			return getTextContents(getConnection());
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			System.out.println("��ȡ����ʧ�ܣ�");
			e.printStackTrace();
			return null;
		}
	}
}
