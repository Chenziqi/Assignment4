
public class ProfessorInfo2014302580377 {
	String name,email,phone,educationBackground,researchInterests;
	double tf;
	public ProfessorInfo2014302580377(){
		
	}
}
