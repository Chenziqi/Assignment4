import java.util.ArrayList;
import java.util.Iterator;
import java.util.regex.Matcher;
import java.util.regex.Pattern;


public class KeywordsMatcher2014302580377 {
	
	private String keyword;
	//��Ҫִ�к���
	public ArrayList<ProfessorInfo2014302580377> fetchKeywords(String keywords){
		this.keyword = keywords;
		ArrayList<ProfessorInfo2014302580377> pis = DataReader2014302580377.getList();
		ArrayList<ProfessorInfo2014302580377> list  = SearchResults(pis);
		for(ProfessorInfo2014302580377 pi:list){
			pi.tf = caculateTF(pi);
		}
		return arrangeOrder(list);
	}
	//�ҵ������ؼ��ʵĽ��ڶ��󲢷���
	public ArrayList<ProfessorInfo2014302580377> SearchResults(ArrayList<ProfessorInfo2014302580377> list){
		ArrayList<ProfessorInfo2014302580377> newList = new ArrayList<ProfessorInfo2014302580377>();
 		String[] keywords = cutWords(this.keyword);
		//boolean ifhave = false;
		for(ProfessorInfo2014302580377 pi:list){
			String text = pi.name+pi.educationBackground+pi.researchInterests+pi.email+pi.phone;
			for(String key:keywords){
				Pattern p = Pattern.compile(key);
				Matcher m = p.matcher(text);
				if(m.find())  break;
			}
			newList.add(pi);
		}
		return newList;
	}
	//����TFֵ
	public double caculateTF(ProfessorInfo2014302580377 pi){
		String text = pi.name+pi.educationBackground+pi.researchInterests+pi.email+pi.phone;
		String[] allWords = cutWords(text);
		String[] keywords = cutWords(keyword);
		double tf = 0.0;
		int b = 0;
		int a = allWords.length;
		System.out.println(a);
		for(String key:keywords){
			//System.out.println(key);
			for(String word:allWords){
				//System.out.println(word+"+"+key);
				key = key.trim();
				//System.out.println(key);
				if(word.equals(key)){
					b=b+1;
				}
				
			}
			tf = tf + (double)b/a;
			//System.out.println(tf);
		}
		return tf;
	}
	//�����ڵ���Ϣ��ת����һ�������ʲ�����Ϊstring����
	public static String[] cutWords(String words){
		//System.out.println(words);
		words.replaceAll(","," ");
		words.replaceAll("/n"," ");
		words.replaceAll("."," ");
		words = words.toLowerCase();
		String[] cutWordsResult = words.split(" ");
		
		//for(String word:cutWordsResult){
			//System.out.println(word);
		//}
		//for(String a:cutWordsResult){
			//System.out.println(a);
		//}
		return cutWordsResult;
	}
	//�����õ��Ľ�����Ϣ������
	public static ArrayList<ProfessorInfo2014302580377> arrangeOrder(ArrayList<ProfessorInfo2014302580377> pil){
		ArrayList<ProfessorInfo2014302580377> orderedList = new ArrayList<ProfessorInfo2014302580377>();
		orderedList.add(0,pil.get(0));
		Iterator<ProfessorInfo2014302580377> it1 =pil.iterator();
		for(int i = 0;i<pil.size();i++){
			ProfessorInfo2014302580377 pi1 = (ProfessorInfo2014302580377) it1.next();
			for(int j = 0;j<orderedList.size();j++){
				ProfessorInfo2014302580377 pi2 = orderedList.get(j);
				if(pi1.tf>=pi2.tf) {
					orderedList.add(j,pi1);
					break;
				}
			}
		}
		return orderedList;
	}
}
